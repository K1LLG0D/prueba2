from flet import *

def main (page: Page):
    
    page.padding = 0
    
    page.add( Text("WEBFORM GENERATOR:"))
 
app(target=main)